import {useLocation} from "react-router-dom";
import {useEffect} from "react";

export default function ScrollToTop() {
    const {pathname, search} = useLocation()

    useEffect(() => {
        window.scrollTo({
            top: 0,
            left: 0,
            behavior: 'smooth'
        });
        return undefined;
    }, [pathname, search])
}