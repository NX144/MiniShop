import {useState} from "react";
import {Link, useNavigate} from "react-router-dom";
import useCartStore from "../store/cartStore";

export default function Header() {

    const getCountProducts = useCartStore(state => state.items);

    let quantityProducts = getCountProducts.reduce((sum, item) => sum + item.quantity, 0);

    const [searchInput, setSearchInput] = useState("");

    const navigate = useNavigate();

    const handleSearch = async (e) => {
        e.preventDefault();

        const query = searchInput.trim();

        if(!query) return;

        navigate(`/?q=${encodeURIComponent(query)}`);
        setSearchInput("");
    }


    return (
        <header className="bg-white border-b border-gray-200">
            <div className="mx-auto max-w-6xl flex items-center justify-between px-4 py-4">
                <Link to="/" className="text-3xl outfit-200 text-gray-900">
                    MiniShop
                </Link>
                <nav className="flex items-center gap-6 text-sm">
                    <form onSubmit={handleSearch} className="relative">
                        <input
                            onChange={(e) => setSearchInput(e.target.value)}
                            value={searchInput}
                            type="text"
                            placeholder="Поиск..."
                            minLength="2"
                            required
                            className="border border-gray-300 w-87.5 px-4 py-4 rounded-xl"
                        />
                        <button type="submit" className="w-10.5 h-10.5 bg-purple-600 hover:bg-purple-700 transition-all rounded-xl absolute right-0 top-[50%] -translate-x-2 translate-y-[-50%] flex items-center justify-center cursor-pointer">
                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <g clipPath="url(#clip0_2_2045)">
                                    <path fillRule="evenodd" clipRule="evenodd" d="M8.625 2.0625C7.7632 2.0625 6.90984 2.23224 6.11364 2.56204C5.31744 2.89184 4.594 3.37523 3.98461 3.98461C3.37523 4.594 2.89184 5.31744 2.56204 6.11364C2.23224 6.90984 2.0625 7.7632 2.0625 8.625C2.0625 9.4868 2.23224 10.3402 2.56204 11.1364C2.89184 11.9326 3.37523 12.656 3.98461 13.2654C4.594 13.8748 5.31744 14.3582 6.11364 14.688C6.90984 15.0178 7.7632 15.1875 8.625 15.1875C10.3655 15.1875 12.0347 14.4961 13.2654 13.2654C14.4961 12.0347 15.1875 10.3655 15.1875 8.625C15.1875 6.88452 14.4961 5.21532 13.2654 3.98461C12.0347 2.7539 10.3655 2.0625 8.625 2.0625ZM0.9375 8.625C0.9375 4.38 4.38 0.9375 8.625 0.9375C12.87 0.9375 16.3125 4.38 16.3125 8.625C16.3125 10.545 15.6083 12.3015 14.4443 13.6485L16.8975 16.1025C16.9528 16.154 16.9971 16.2161 17.0278 16.2851C17.0586 16.3541 17.0751 16.4286 17.0764 16.5041C17.0778 16.5796 17.0639 16.6547 17.0356 16.7247C17.0073 16.7947 16.9652 16.8584 16.9118 16.9118C16.8584 16.9652 16.7947 17.0073 16.7247 17.0356C16.6547 17.0639 16.5796 17.0778 16.5041 17.0764C16.4286 17.0751 16.3541 17.0586 16.2851 17.0278C16.2161 16.9971 16.154 16.9528 16.1025 16.8975L13.6485 14.4443C12.2537 15.6518 10.4699 16.3152 8.625 16.3125C4.38 16.3125 0.9375 12.87 0.9375 8.625Z" fill="white"/>
                                </g>
                                <defs>
                                    <clipPath id="clip0_2_2045">
                                        <rect width="18" height="18" fill="white"/>
                                    </clipPath>
                                </defs>
                            </svg>
                        </button>
                    </form>
                    <Link to="/" className="text-gray-700 hover:text-gray-900">
                        Каталог
                    </Link>
                    <Link to="/cart" className="text-gray-700 hover:text-gray-900">
                        Корзина ({quantityProducts})
                    </Link>
                </nav>
            </div>
        </header>
    )
}